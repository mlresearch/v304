python ./leetcode/code_score.py \
--test_case kotlin-small-test \
--model CodeLlama-13b-Instruct-hf \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case kotlin-small-test \
--model Llama-3.1-8B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case kotlin-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case scala-small-test \
--model CodeLlama-13b-Instruct-hf \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case scala-small-test \
--model Llama-3.1-8B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case scala-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case php-small-test \
--model CodeLlama-13b-Instruct-hf \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case php-small-test \
--model Llama-3.1-8B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./leetcode/code_score.py \
--test_case php-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3