python ./bigcodebench/code_score.py \
--test_case codellama--CodeLlama-13b-Instruct-hf-small \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 1 \
--analyze_prompt 0 \
--temperature 0.4 \
--return_type bool \
--num_samples 3

python ./bigcodebench/code_score.py \
--test_case codellama--CodeLlama-13b-Instruct-hf-small \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--return_type bool \
--num_samples 3