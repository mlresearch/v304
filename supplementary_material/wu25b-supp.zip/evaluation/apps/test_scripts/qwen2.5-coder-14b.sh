python ./apps/code_score.py \
--test_case gpt \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--return_type bool \
--num_samples 3