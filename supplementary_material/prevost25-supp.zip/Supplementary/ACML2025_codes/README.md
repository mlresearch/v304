BanditTools is requiere to run :
- "Generate data for Simulation 1.py"
- "Generate data for Simulation 2.py"
- "Generate data for Simulation 3.py"

To run "Plot Simulation 1.py" you must first generate data from "Generate data for Simulation 1.py"

To run "Plot Simulation 2.py" you must first generate data from "Generate data for Simulation 2.py"

To run "Plot Simulation 3.py" you must first generate data from "Generate data for Simulation 1.py" AND "Generate data for Simulation 3.py"