OUTPUT_PATH="./output/math-test-Llama-2-7b"
DATA_PATH="./data"

python gen_vllm.py \
    --model $OUTPUT_PATH \
    --data_path $DATA_PATH \
    --sub_task python \
    --output_file $OUTPUT_PATH/python_response.jsonl

python code_process.py --path $OUTPUT_PATH/python_response.jsonl

evalplus.evaluate --dataset humaneval --samples $OUTPUT_PATH/humaneval.jsonl
evalplus.evaluate --dataset mbpp --samples $OUTPUT_PATH/mbpp.jsonl

