python ./humaneval/code_score.py \
--test_case cpp-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./humaneval/code_score.py \
--test_case java-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./humaneval/code_score.py \
--test_case go-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3

python ./humaneval/code_score.py \
--test_case js-small-test \
--model Qwen2.5-Coder-14B-Instruct \
--step 2 \
--compare_prompt 0 \
--analyze_prompt 0 \
--temperature 0.4 \
--with_prefix \
--return_type bool \
--num_samples 3