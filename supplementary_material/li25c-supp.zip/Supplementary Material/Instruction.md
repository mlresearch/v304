# Instruction
## Code Availability
The code for this paper has been open-sourced and is available on GitHub. During the blind review period, an anonymous GitHub repository link was provided.

## Implementation Details
Detailed explanations of various methods can be found in the paper's appendix.

## Dataset Information
The provided classification data has undergone both LLM review and manual spot-checking. The JSON filenames indicate the sampling method used. Please note that SimANS+Positive-Centric Retrieval also includes TopK sampling after retrieval.
