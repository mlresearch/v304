## Requirements 
Python >= 3.10
You need to set up your Hugging Face token and have the necessary permissions to download the CodeLlama, Llama3.1, and Qwen2.5 models.

## Setup
```
conda create -n crosspyeval python=3.10 -y
conda activate crosspyeval
pip install -r requirements.txt
```

## Example
you can run HumanEval-X test by:
```
cd CrossPyEval/evaluation/
bash humaneval/test_scripts/qwen2.5-coder-14b.sh
```

## Result
For example, check the result of cpp test cases
```
python humaneval/calculate_accuracy --test_cases cpp-small-test 
```